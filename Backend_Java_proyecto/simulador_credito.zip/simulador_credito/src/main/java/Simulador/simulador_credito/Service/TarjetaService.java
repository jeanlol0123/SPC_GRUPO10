/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Simulador.simulador_credito.Service;
import  Simulador.simulador_credito.Models.Tarjeta;
import java.util.List;

/**
 *
 * @author Nelson Zamudio
 */
public interface TarjetaService {
            
    public Tarjeta save (Tarjeta tarjeta);
    public void delete(Integer id);
    public Tarjeta findByid(Integer id);
    public List<Tarjeta>findByAll();
   
    
    
}
