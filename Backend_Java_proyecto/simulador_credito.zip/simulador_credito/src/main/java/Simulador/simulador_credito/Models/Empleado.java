xpackage Simulador.simulador_credito.Models;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.*;




@Table
@Entity(name="empleado")
public class Empleado implements Serializable {
    @Id
    @Column(name="Cedula")
    private int Cedula;
    @Column(name="Nombre")
    private String Nombre;
    @Column(name="Apellido")
    private String Apellido;
    @Column(name="Telefono")
    private int Telefono;
    @Column(name="Cargo")
    private String Cargo;
    @Column(name="Contraseña")
    private int Contraseña;
    @Column(name="Correo")
    private String Correo;
    @ManyToOne
    @JoinColumn(name="id_banco")
    private Banco banco;
    public Empleado() {
    }

    public Empleado(int Cedula, String Nombre, String Apellido, int Telefono, String Cargo, int Contraseña, String Correo, Banco banco) {
        this.Cedula = Cedula;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Telefono = Telefono;
        this.Cargo = Cargo;
        this.Contraseña = Contraseña;
        this.Correo = Correo;
        this.banco = banco;
    }

    public int getCedula() {
        return Cedula;
    }

    public void setCedula(int Cedula) {
        this.Cedula = Cedula;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getTelefono() {
        return Telefono;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }

    public String getCargo() {
        return Cargo;
    }

    public void setCargo(String Cargo) {
        this.Cargo = Cargo;
    }

    public int getContraseña() {
        return Contraseña;
    }

    public void setContraseña(int Contraseña) {
        this.Contraseña = Contraseña;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public Banco getBanco() {
        return banco;
    }

    public void setBanco(Banco banco) {
        this.banco = banco;
    }
    
}
