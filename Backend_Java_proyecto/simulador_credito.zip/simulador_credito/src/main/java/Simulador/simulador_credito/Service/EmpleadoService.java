/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Simulador.simulador_credito.Service;
import  Simulador.simulador_credito.Models.Empleado;
import java.util.List;

/**
 *
 * @author Nelson Zamudio
 */
public interface EmpleadoService {
    
    public Empleado save (Empleado empleado);
    public void delete(Integer id);
    public Empleado findByid(Integer id);
    public List<Empleado>findByAll();
   
    
    
    
}
