package Simulador.simulador_credito.Controller;
import Simulador.simulador_credito.Models.Banco;
import Simulador.simulador_credito.Service.BancoService;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/banco")




public class BancoController {
    @Autowired
    private BancoService bancoService;
    
    @PostMapping(value="/")
    public ResponseEntity<Banco> agregar(@RequestBody Banco banco){
        Banco obj = bancoService.save(banco);
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @DeleteMapping(value="/{id}")
    public ResponseEntity<Banco> eliminar(@PathVariable Integer id){
        Banco obj = bancoService.findByid(id);
        if(obj!=null){
            bancoService.delete(id);
        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @PutMapping(value="/")
    public ResponseEntity<Banco> editar(@RequestBody Banco banco){
        Banco obj = bancoService.findByid(banco.getNIT());
        if(obj!=null){
            obj.setNombre(banco.getNombre());
            obj.setDirección(banco.getDirección());
            bancoService.save(obj);
        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @GetMapping("/list")
    public List<Banco> consultarTodo(){
        return bancoService.findByAll();
    }
    
    @GetMapping("/list/{id}")
    public Banco consultarPorId(@PathVariable Integer id){
        return bancoService.findByid(id);
    }


}
