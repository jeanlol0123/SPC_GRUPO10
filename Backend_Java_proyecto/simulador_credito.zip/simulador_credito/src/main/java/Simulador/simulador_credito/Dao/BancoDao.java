package Simulador.simulador_credito.Dao;
import Simulador.simulador_credito.Models.Banco;
import org.springframework.data.repository.CrudRepository;
public interface BancoDao extends CrudRepository<Banco,Integer>{
    
}
