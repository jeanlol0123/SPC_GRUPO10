package Simulador.simulador_credito.Dao;

import Simulador.simulador_credito.Models.Tarjeta;
import org.springframework.data.repository.CrudRepository;
public interface TarjetaDao extends CrudRepository<Tarjeta,Integer>{
    
}
