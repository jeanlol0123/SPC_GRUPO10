
package Simulador.simulador_credito.Controller;
import Simulador.simulador_credito.Models.Tarjeta;
import Simulador.simulador_credito.Service.TarjetaService;
import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/tarjeta")
public class TarjetaController {
    @Autowired
    private TarjetaService tarjetaService;
    
    @PostMapping(value="/")
    public ResponseEntity<Tarjeta> agregar(@RequestBody Tarjeta tarjeta){
        Tarjeta obj = tarjetaService.save(tarjeta);
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @DeleteMapping(value="/{id}")
    public ResponseEntity<Tarjeta> eliminar(@PathVariable Integer id){
        Tarjeta obj = tarjetaService.findByid(id);
        if(obj!=null){
            tarjetaService.delete(id);
        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @PutMapping(value="/")
    public ResponseEntity<Tarjeta> editar(@RequestBody Tarjeta tarjeta){
        Tarjeta obj = tarjetaService.findByid(tarjeta.getId());
        if(obj!=null){
            obj.setNombre(tarjeta.getNombre());
            obj.setInteres(tarjeta.getInteres());
            tarjetaService.save(obj);
        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @GetMapping("/list")
    public List<Tarjeta> consultarTodo(){
        return tarjetaService.findByAll();
    }
    
    @GetMapping("/list/{id}")
    public Tarjeta consultarPorId(@PathVariable Integer id){
        return tarjetaService.findByid(id);
    }
}
