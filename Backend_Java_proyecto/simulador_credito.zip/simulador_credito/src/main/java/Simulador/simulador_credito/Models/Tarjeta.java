package Simulador.simulador_credito.Models;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.*;
@Table
@Entity(name="tarjeta")


public class Tarjeta  implements Serializable {
    @Id
    @Column(name="id")
    private int id;
    @Column(name="Nombre")
    private String Nombre;
    @Column(name="Interes")
    private String Interes;
    @ManyToOne
   @JoinColumn(name="Banco_NIT", referencedColumnName="NIT")
    private Banco banco;

    public Tarjeta() {
    }

    public Tarjeta(int id, String Nombre, String Interes, Banco banco) {
        this.id = id;
        this.Nombre = Nombre;
        this.Interes = Interes;
        this.banco = banco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getInteres() {
        return Interes;
    }

    public void setInteres(String Interes) {
        this.Interes = Interes;
    }

    public Banco getBanco() {
        return banco;
    }

    public void setBanco(Banco banco) {
        this.banco = banco;
    }
    
}
