package Simulador.simulador_credito.Models;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.*;



@Table
@Entity(name="banco")
public class Banco implements Serializable {
     @Id
    @Column(name="NIT")
    private int NIT;
    @Column(name="Nombre")
    private String Nombre;
    @Column(name="Dirección")
    private String Dirección;
    public Banco() {
    }

    public Banco(int NIT, String Nombre, String Dirección) {
        this.NIT = NIT;
        this.Nombre = Nombre;
        this.Dirección = Dirección;
    }

    public int getNIT() {
        return NIT;
    }

    public void setNIT(int NIT) {
        this.NIT = NIT;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDirección() {
        return Dirección;
    }

    public void setDirección(String Dirección) {
        this.Dirección = Dirección;
    }

}
