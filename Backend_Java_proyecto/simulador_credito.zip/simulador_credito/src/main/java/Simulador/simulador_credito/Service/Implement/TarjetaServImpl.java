package Simulador.simulador_credito.Service.Implement;

import Simulador.simulador_credito.Dao.TarjetaDao;
import Simulador.simulador_credito.Models.Tarjeta;
import Simulador.simulador_credito.Service.TarjetaService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class TarjetaServImpl  implements TarjetaService {
@Autowired
    private TarjetaDao tarjetaDao;
    
    @Override
    @Transactional(readOnly=false)
    public Tarjeta save(Tarjeta tarjeta){
        return tarjetaDao.save(tarjeta);
    }
    
    @Override
    @Transactional(readOnly=false)
    public void delete(Integer id){
        tarjetaDao.deleteById(id);
    }
    
    @Override
    @Transactional(readOnly=true)
    public Tarjeta findByid(Integer id){
        return tarjetaDao.findById(id).orElse(null);
    }
    
    @Override
    @Transactional(readOnly=true)
    public List<Tarjeta> findByAll(){
        return (List<Tarjeta>) tarjetaDao.findAll();
    }
    
}
