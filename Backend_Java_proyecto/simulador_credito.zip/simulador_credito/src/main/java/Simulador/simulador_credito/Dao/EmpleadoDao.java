package Simulador.simulador_credito.Dao;
import Simulador.simulador_credito.Models.Empleado;
import org.springframework.data.repository.CrudRepository;
public interface EmpleadoDao extends CrudRepository<Empleado, Integer>{

    
}