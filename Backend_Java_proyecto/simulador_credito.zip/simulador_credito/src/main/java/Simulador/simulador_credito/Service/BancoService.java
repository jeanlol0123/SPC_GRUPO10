/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Simulador.simulador_credito.Service;
import  Simulador.simulador_credito.Models.Banco;
import java.util.List;

/**
 *
 * @author Nelson Zamudio
 */
public interface BancoService {
        
    public Banco save (Banco banco);
    public void delete(Integer id);
    public Banco findByid(Integer id);
    public List<Banco> findByAll();
   
    
    
    
}
