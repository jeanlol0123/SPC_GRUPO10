const url = "http://localhost:8080/empleado/"
const url1 = "http://localhost:8080/empleado/list"
const contenedor = document.querySelector('tbody')
let resultados = ''

const modalProveedores = new bootstrap.Modal(document.getElementById('modalEmpleado'))
const formEmpleado = document.querySelector('form')
const cedulaEmpleado = document.getElementById('Cedula')
const nombreEmpleado = document.getElementById('Nombre')
const apellidoEmpleado = document.getElementById('Apellido')
const telefonoEmpleado = document.getElementById('Telefono')
const cargoEmpleado = document.getElementById('Cargo')
const emailEmpleado = document.getElementById('email')
const contraseñaEmpleado = document.getElementById('Password')
let opcion = ''

btnCrear.addEventListener('click', () => {
     console.log("Si funciona")
    cedulaEmpleado.value = ''
    nombreEmpleado.value = ''
    apellidoEmpleado.value = ''
    telefonoEmpleado.value = ''
    cargoEmpleado.value = ''
    emailEmpleado.value = ''
    contraseñaEmpleado.value = ''
    modalProveedores.show()
    opcion = 'crear'
})

//btnCerrar.addEventListener('click', () => {
    
//    modalProveedores.hide()
   
//})

//btnclose.addEventListener('click', () => {
    
//    modalProveedores.hide()
   
//})
//funcion para mostrar resultados

const mostrar = (Proveedores) => {
    Proveedores.forEach(Proveedor => {
        resultados += `<tr>
                        <td>${Proveedor.id_proveedor}</td>
                        <td>${Proveedor.nombre_proveedor}</td>
                        <td>${Proveedor.email_proveedor}</td>
                        <td class="text-center" width="20%"><a class="btnEditar btn btn-primary">Editar</a><a class="btnBorrar btn btn-danger">Borrar</a></td>
                    </tr>`
    })

    contenedor.innerHTML = resultados
}

//procedimiento mostrar registros
fetch(url1)
    .then(response => response.json())
    .then(data => mostrar(data))
    .catch(error => console.log(error))

const on = (element, event, selector, handler) => {
    element.addEventListener(event, e => {
        if (e.target.closest(selector))
            handler(e)
    })
}

on(document, 'click', '.btnBorrar', e => {
    const fila = e.target.parentNode.parentNode
    const id = fila.firstElementChild.innerHTML
    console.log(id)

    alertify.confirm("Desea eliminar el Proveedor "+id,
        function () {
            fetch(url + id, {
                method: 'DELETE'
            })
                .then(() => location.reload())
        },
        function () {
            alertify.error('Cancelado')
        });
})

let idForm = 0
on(document, 'click', '.btnEditar', e => {

    const fila = e.target.parentNode.parentNode
    
    idForm = fila.children[0].innerHTML
    const nombre = fila.children[1].innerHTML
    const email = fila.children[2].innerHTML
    idProveedor.value = idForm
    idProveedor.disabled = true
    nombreProveedor.value = nombre
    emailProveedor.value = email

    opcion = 'editar'
    modalProveedores.show()
})

formEmpleado.addEventListener('submit', (e) => {
    e.preventDefault()

        if (opcion == 'crear') {
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                  Cedula : cedulaEmpleado.value,
                    Nombre : nombreEmpleado.value,
                    Apellido : apellidoEmpleado.value,  
                    Telefono : telefonoEmpleado.value,
                    Cargo : cargoEmpleado.value,
                    Contraseña : contraseñaEmpleado.value,
                    Correo : emailEmpleado.value,
                    banco : "1"
                })
            })
                .then(response => response.json())
                .then(data => {
                    const nuevoProveedor = []
                    nuevoProveedor.push(data)
                    mostrar(nuevoProveedor)
                })
        }
        if (opcion == 'editar') {

            fetch(url, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id_proveedor: idForm,
                    nombre_proveedor: nombreProveedor.value,
                    email_proveedor: emailProveedor.value
                })
            })
                .then(response => location.reload())

        }
        modalProveedores.hide()
    
})
