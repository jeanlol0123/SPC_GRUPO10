package Simulador.simulador_credito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimuladorCreditoApplicationTests {

	@Test
	void contextLoads() {
	}

}
